package br.com.jdbc.beans;

import java.sql.Date;

public class Funcionario {

	private int codigo;
	private String nome;
	private String rg;
	private Date dataNasc;
	private String Cpf;
	
	public Funcionario(int codigo, String nome, String rg, Date dataNasc, String cpf) {
		super();
		this.codigo = codigo;
		this.nome = nome;
		this.rg = rg;
		this.dataNasc = dataNasc;
		Cpf = cpf;
	}
	
	public Funcionario() {
		super();
	}
	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getRg() {
		return rg;
	}

	public void setRg(String rg) {
		this.rg = rg;
	}

	public Date getDataNasc() {
		return dataNasc;
	}

	public void setDataNasc(Date dataNasc) {
		this.dataNasc = dataNasc;
	}

	public String getCpf() {
		return Cpf;
	}

	public void setCpf(String cpf) {
		Cpf = cpf;
	}
	
	
}
