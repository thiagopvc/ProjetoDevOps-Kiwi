package br.com.jdbc.principal;

import javax.swing.JOptionPane;

import br.com.jdbc.beans.Funcionario;
import br.com.jdbc.dao.FuncionarioDAO;


public class TesteConsultarFuncionario {
	public static void main(String[] args) {
		try {
			FuncionarioDAO dao = new FuncionarioDAO();
			int x = Integer.parseInt
					(JOptionPane.showInputDialog("Digite o c�digo"));
			Funcionario funcionario = dao.getUser(x);
			System.out.println("Nome --> " + funcionario.getNome());
			System.out.println("CPF --> " + funcionario.getCpf());
			System.err.println("RG --> " + funcionario.getRg());
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
