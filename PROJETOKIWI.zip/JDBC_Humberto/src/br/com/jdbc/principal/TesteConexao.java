package br.com.jdbc.principal;

import java.sql.Connection;

import br.com.jdbc.conexao.Conexao;

public class TesteConexao {

	public static void main(String[] args) {
		try {
			Connection con = Conexao.getConnection();
			System.out.println("Conectado");
			con.close();
		}catch(Exception e) {
			e.printStackTrace();
		}

	}

}
