package br.com.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import br.com.jdbc.beans.Funcionario;
import br.com.jdbc.conexao.Conexao;

public class FuncionarioDAO {
	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;
	

	public void close() throws Exception{
		con.close();
	}
	
	public FuncionarioDAO() throws Exception{
		con = Conexao.getConnection();
	}
	
	public Funcionario getUser(int codigo) throws Exception{
		stmt = con.prepareStatement("SELECT * FROM TB_FUNCIONARIO WHERE CD_FUNCIONARIO=?");
		stmt.setInt(1, codigo);//1=POSI��O DO 1� PONTO DE INTERROGA��O
		rs=stmt.executeQuery();
		if(rs.next()) {
			Funcionario objeto = new Funcionario();
			objeto.setCodigo(rs.getInt("CD_FUNCIONARIO"));
			objeto.setNome(rs.getString("NM_FUNCIONARIO"));
			objeto.setRg(rs.getString("NR_RG_FUNCIONARIO"));
			objeto.setDataNasc(rs.getDate("DT_NASCIMENTO"));
			objeto.setCpf(rs.getString("NR_CPF_FUNCIONARIO"));			
	
			return objeto;
			
		}else {
			return new Funcionario();
		}
	}
}
